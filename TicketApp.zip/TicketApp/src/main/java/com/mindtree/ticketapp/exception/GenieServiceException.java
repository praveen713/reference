package com.mindtree.ticketapp.exception;

public class GenieServiceException extends TicketAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GenieServiceException() {
		// TODO Auto-generated constructor stub
	}

	public GenieServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GenieServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public GenieServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GenieServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
