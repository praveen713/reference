package com.mindtree.ticketapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class,
property = "genieId")
public class Genie {
	@Id
	@Column
	private int genieId;
	@Column
	private String genieDescription;
	@Column
	private boolean genieStatus;
	@ManyToOne
	private CampusMind campusMind;
	public int getGenieId() {
		return genieId;
	}
	public void setGenieId(int genieId) {
		this.genieId = genieId;
	}
	public String getGenieDescription() {
		return genieDescription;
	}
	public void setGenieDescription(String genieDescription) {
		this.genieDescription = genieDescription;
	}
	
	public boolean isGenieStatus() {
		return genieStatus;
	}
	public void setGenieStatus(boolean genieStatus) {
		this.genieStatus = genieStatus;
	}
	public CampusMind getCampusMind() {
		return campusMind;
	}
	public void setCampusMind(CampusMind campusMind) {
		this.campusMind = campusMind;
	}
	

}
