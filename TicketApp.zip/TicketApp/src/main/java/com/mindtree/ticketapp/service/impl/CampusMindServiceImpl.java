package com.mindtree.ticketapp.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ticketapp.dto.CampusMindDto;
import com.mindtree.ticketapp.entity.CampusMind;
import com.mindtree.ticketapp.exception.CampusMindServiceException;
import com.mindtree.ticketapp.repository.CampusMindRepository;
import com.mindtree.ticketapp.service.CampusMindService;

@Service
public class CampusMindServiceImpl implements CampusMindService {
	
	@Autowired
	CampusMindRepository campusMindRepository;
	
    ModelMapper modelMapper=new ModelMapper();
	

	
	public CampusMindDto convertEntityToDto(CampusMind campusMind)  {
		return modelMapper.map(campusMind,CampusMindDto.class);
	}

	@Override
	public CampusMindDto addCampusMind(CampusMind campusMind) throws CampusMindServiceException{
		campusMindRepository.save(campusMind);
		return convertEntityToDto(campusMind);
	}

	@Override
	public Map<Integer, CampusMindDto> getAllCampusMind() throws CampusMindServiceException {
		Set<CampusMind> campusMinds=new HashSet<CampusMind>();
		campusMindRepository.findAll().forEach(CampusMind->campusMinds.add(CampusMind));
		Map<Integer, CampusMindDto> listCampusMind=new HashMap<Integer, CampusMindDto>();
		for (CampusMind campusMind : campusMinds) {
			listCampusMind.put(campusMind.getmId(), convertEntityToDto(campusMind));
		}
		return listCampusMind;
	}

	
}
