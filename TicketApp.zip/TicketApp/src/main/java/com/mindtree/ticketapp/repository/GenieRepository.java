package com.mindtree.ticketapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.mindtree.ticketapp.entity.Genie;

public interface GenieRepository extends CrudRepository<Genie, Integer> {

	@Query("SELECT g FROM Genie g where g.campusMind.mId=?1 and g.genieStatus=1")
	public List<Genie> filterGenieByStatus(int campusMindId);
}
