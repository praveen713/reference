package com.mindtree.ticketapp.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class CampusMind {
	@Id
	private int mId;
	@Column
	private String name;
	@Column
	private String projectName;
	@OneToMany(mappedBy = "campusMind")
	private List<Genie> genies;
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public List<Genie> getGenies() {
		return genies;
	}
	public void setGenies(List<Genie> genies) {
		this.genies = genies;
	}
	
	
	

}
