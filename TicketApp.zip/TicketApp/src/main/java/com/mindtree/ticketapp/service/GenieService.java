package com.mindtree.ticketapp.service;

import java.util.List;

import com.mindtree.ticketapp.dto.GenieDto;
import com.mindtree.ticketapp.entity.Genie;
import com.mindtree.ticketapp.exception.GenieServiceException;

public interface GenieService {
	public List<GenieDto> displayAllGenieByNotResolved(int campusMindId) throws GenieServiceException;
	public GenieDto changeStatusOfGenie(Genie genie) throws GenieServiceException;
	public GenieDto raiseGenie(Genie genie) throws GenieServiceException;

}
