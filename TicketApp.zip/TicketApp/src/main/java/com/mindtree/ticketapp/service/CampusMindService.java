package com.mindtree.ticketapp.service;

import java.util.Map;

import com.mindtree.ticketapp.dto.CampusMindDto;
import com.mindtree.ticketapp.entity.CampusMind;
import com.mindtree.ticketapp.exception.CampusMindServiceException;

public interface CampusMindService {
   public CampusMindDto addCampusMind(CampusMind campusMind) throws CampusMindServiceException;
   public Map<Integer,CampusMindDto> getAllCampusMind() throws CampusMindServiceException;
}
