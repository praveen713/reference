package com.mindtree.ticketapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.mindtree.ticketapp.entity.CampusMind;

public interface CampusMindRepository extends CrudRepository<CampusMind, Integer> {
	

}
