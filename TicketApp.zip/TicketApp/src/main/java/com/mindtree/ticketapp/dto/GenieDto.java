package com.mindtree.ticketapp.dto;

public class GenieDto {
	
	private String genieDescription;
	private String genieStatus;
	
	public String getGenieDescription() {
		return genieDescription;
	}
	public void setGenieDescription(String genieDescription) {
		this.genieDescription = genieDescription;
	}
	public String getGenieStatus() {
		return genieStatus;
	}
	public void setGenieStatus(String genieStatus) {
		this.genieStatus = genieStatus;
	}
	

}
