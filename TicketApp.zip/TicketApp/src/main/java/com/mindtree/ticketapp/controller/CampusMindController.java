package com.mindtree.ticketapp.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ticketapp.dto.CampusMindDto;
import com.mindtree.ticketapp.entity.CampusMind;
import com.mindtree.ticketapp.exception.TicketAppException;
import com.mindtree.ticketapp.service.impl.CampusMindServiceImpl;

@RestController
@RequestMapping("campusMind")
public class CampusMindController {
	
	@Autowired
	CampusMindServiceImpl campusMindServiceImpl;
	
	
	@PostMapping("/add")
	public ResponseEntity<CampusMindDto> addCampusMind(@RequestBody CampusMind campusMind) throws TicketAppException {
		CampusMindDto campusMindDto=campusMindServiceImpl.addCampusMind(campusMind);
    	return new ResponseEntity<CampusMindDto>(campusMindDto, HttpStatus.CREATED);
	}
	
	@GetMapping("/get")
	public ResponseEntity<Map<Integer, CampusMindDto>> getAllCampusMind() throws TicketAppException{
		Map<Integer, CampusMindDto> listCampusMind=campusMindServiceImpl.getAllCampusMind();
		return new ResponseEntity<Map<Integer, CampusMindDto>>(listCampusMind, HttpStatus.FOUND);
	}

}
