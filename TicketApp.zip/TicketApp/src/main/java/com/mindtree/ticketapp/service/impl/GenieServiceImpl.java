package com.mindtree.ticketapp.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ticketapp.dto.GenieDto;
import com.mindtree.ticketapp.entity.CampusMind;
import com.mindtree.ticketapp.entity.Genie;
import com.mindtree.ticketapp.exception.GenieServiceException;
import com.mindtree.ticketapp.exception.service.InvalidGenieIdException;
import com.mindtree.ticketapp.exception.service.InvalidMidException;
import com.mindtree.ticketapp.repository.CampusMindRepository;
import com.mindtree.ticketapp.repository.GenieRepository;
import com.mindtree.ticketapp.service.GenieService;

@Service
public class GenieServiceImpl implements GenieService {
	
	@Autowired
	GenieRepository genieRepository;
	
	@Autowired
	CampusMindRepository campusMindRepository;
	
	ModelMapper modelMapper=new ModelMapper();
		

		
    public GenieDto convertEntityToDto(Genie genie)  {
			return modelMapper.map(genie,GenieDto.class);
	}

	@Override
	public List<GenieDto> displayAllGenieByNotResolved(int campusMindId) throws GenieServiceException {
		List<Genie> genies=new ArrayList<Genie>();
		genieRepository.filterGenieByStatus(campusMindId).forEach(genie->genies.add(genie));
		List<GenieDto> genieDtos=new ArrayList<GenieDto>();
		for (Genie genie : genies) {
			genieDtos.add(convertEntityToDto(genie));
		} 
		return genieDtos;
	}

	

	@Override
	public GenieDto raiseGenie(Genie genie) throws GenieServiceException  {
		Optional<CampusMind> campusMind=campusMindRepository.findById(genie.getCampusMind().getmId());
		campusMind.orElseThrow(()-> new InvalidMidException("Invalid  Mid"));
		genieRepository.save(genie);
		return convertEntityToDto(genie);
	}



	@Override
	public GenieDto changeStatusOfGenie(Genie genie) throws GenieServiceException {
	  Optional<Genie> genieOne=genieRepository.findById(genie.getGenieId());
	  genieOne.orElseThrow(()-> new InvalidGenieIdException("Invalid Genie Id"));
	  genieRepository.save(genie);
	  return convertEntityToDto(genie);
	}

}
