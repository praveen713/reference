package com.mindtree.ticketapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ticketapp.dto.GenieDto;
import com.mindtree.ticketapp.entity.CampusMind;
import com.mindtree.ticketapp.entity.Genie;
import com.mindtree.ticketapp.exception.TicketAppException;
import com.mindtree.ticketapp.service.impl.GenieServiceImpl;

@RestController
@RequestMapping("genie")
public class GenieController {
	
	@Autowired
	GenieServiceImpl genieServiceImpl;
	
	
	
	@PostMapping("/add/{campusMindId}")
	public ResponseEntity<GenieDto> raiseGenie(@PathVariable("campusMindId") int campusMindId,@RequestBody Genie genie) throws TicketAppException {
		CampusMind campusMind=new CampusMind();
		campusMind.setmId(campusMindId);
		genie.setCampusMind(campusMind);
		GenieDto genieDto=genieServiceImpl.raiseGenie(genie);
    	return new ResponseEntity<GenieDto>(genieDto, HttpStatus.CREATED);
	} 
	
	@PostMapping("/update")
	public ResponseEntity<GenieDto> updateGenieStatus(@RequestBody Genie genie) throws TicketAppException{
		GenieDto genieDto=genieServiceImpl.changeStatusOfGenie(genie);
		return new ResponseEntity<GenieDto>(genieDto, HttpStatus.FOUND);
	}
	
	@GetMapping("/get/{campusMindId}")
	public ResponseEntity<List<GenieDto>> getAllGenieByCampusMindIdNotResolved(@PathVariable("campusMindId") int campusMindId) throws TicketAppException{
		List<GenieDto> genieDtos= genieServiceImpl.displayAllGenieByNotResolved(campusMindId);
		return new ResponseEntity<List<GenieDto>>(genieDtos, HttpStatus.FOUND);
	}

}
